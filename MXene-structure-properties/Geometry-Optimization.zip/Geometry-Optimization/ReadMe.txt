1. Geometry_ABC.tar.gz - contains CONTCAR files with the optimized geometry of each bare M3C2 MXene with ABC stacking

2. Geometry_ABChM.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABC-hM configuration

3. Geometry_ABChX.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABC-hX configuration

4. Geometry_ABCm.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABC-m configuration

5. Geometry_ABCt.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABC-t configuration

6. Geometry_ABA.tar.gz - contains CONTCAR files with the optimized geometry of each bare M3C2 MXene with ABA stacking

7. Geometry_ABAh.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABA-h configuration

8. Geometry_ABAhX.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABA-hX configuration

9. Geometry_ABAm.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABA-m configuration

10. Geometry_ABAt.tar.gz - contains CONTCAR files with the optimized geometry of each terminated M3C2T2 MXene in the ABA-t configuration

11. GeometryOptimization_M3C2 - contains folders with essential input and output files from the geometry optimization of the most stable stacking configuration for each bare M3C2 MXene (M = Ti, V, Cr, Zr, Nb, Mo, Hf, Ta, W). No pre- or post-processing is required for the geometry optimization calculations.

12. GeometryOptimization_Ti3C2T2 - contains folders with essential input and output files from the geometry optimization of the most stable stacking configuration for each terminated Ti3C2T2 MXene (T = O, S, Se, Te, F, Cl, Br, NH, OH). No pre- or post-processing is required for geometry optimization calculations.

